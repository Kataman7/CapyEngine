#version 330 core

in vec2 TexCoords;        // Coordonnées de texture venant du vertex shader
out vec4 FragColor;       // Couleur de sortie du fragment shader

uniform sampler2D texture0;  // Texture d'entrée

void main()
{
    // Récupération de la couleur du pixel actuel
    vec4 texColor = texture(texture0, TexCoords);
    
    // Calcul de la valeur de luminosité moyenne (moyenne pondérée des composantes R, G et B)
    float gray = 0.299 * texColor.r + 0.587 * texColor.g + 0.114 * texColor.b;
    
    // Application de cette valeur à toutes les composantes R, G et B pour obtenir le noir et blanc
    FragColor = vec4(vec3(gray), texColor.a);
}
