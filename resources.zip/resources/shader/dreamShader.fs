#version 330

in vec2 fragTexCoord;    // Coordonn�es de texture interpol�es
uniform sampler2D texture0;  // Texture de l'image
uniform vec2 screenSize;  // Taille de l'�cran

out vec4 finalColor;      // Couleur de sortie

// Fonction pour ajouter du bruit
float rand(vec2 co)
{
    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main()
{
    vec2 texSize = screenSize;
    vec2 uv = fragTexCoord;

    // Couleur de base
    vec4 color = texture(texture0, uv);

    // Flouter l�g�rement pour obtenir un effet pastel
    vec4 blur = (
        texture(texture0, uv + vec2(0.001, 0.001)) +
        texture(texture0, uv + vec2(-0.001, -0.001)) +
        texture(texture0, uv + vec2(0.001, -0.001)) +
        texture(texture0, uv + vec2(-0.001, 0.001))
    ) / 4.0;

    // Ajouter un l�ger contour en accentuant les diff�rences de couleurs
    vec4 edge = vec4(0.0);
    edge += abs(texture(texture0, uv + vec2(1.0 / texSize.x, 0.0)) - color);
    edge += abs(texture(texture0, uv - vec2(1.0 / texSize.x, 0.0)) - color);
    edge += abs(texture(texture0, uv + vec2(0.0, 1.0 / texSize.y)) - color);
    edge += abs(texture(texture0, uv - vec2(0.0, 1.0 / texSize.y)) - color);
    edge = vec4(vec3(edge.r + edge.g + edge.b) * 0.5);

    // Ajouter un bruit pour un effet de texture de peinture
    float noise = rand(uv * texSize);
    vec4 noiseColor = vec4(vec3(noise * 0.1), 1.0);

    // M�langer tout pour obtenir l'effet final
    finalColor = mix(color, blur, 0.5) + edge * 0.5 + noiseColor * 0.3;
    finalColor.a = 1.0;  // Assurer une opacit� totale
}
